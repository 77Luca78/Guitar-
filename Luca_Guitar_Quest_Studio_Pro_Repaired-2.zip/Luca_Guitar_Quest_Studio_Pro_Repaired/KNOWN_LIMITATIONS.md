# Bekannte Grenzen

- Kommerzielle Songs im persönlichen Katalog sind Referenz- und Rhythmus-Templates, keine exakten Arrangements.
- Exakte Noten, Tabs und Backing-Tracks benötigen legal nutzbare Dateien oder Lizenzen.
- Akkorderkennung über ein Tablet-Mikrofon bleibt eine Beta-Funktion und ist anfällig für Nebengeräusche.
- GuitarPro-Binärformate sind als Quellen vorbereitet, aber nicht vollständig geparst.
- Spotify-/YouTube-Links werden nicht heruntergeladen oder analysiert.
- Eine Garantie auf absolute Fehlerfreiheit auf jedem Browser und jeder iPadOS-Version ist technisch nicht möglich; die getesteten Kernabläufe laufen ohne erkannte interne Fehler.
