# Luca Guitar Quest Studio Pro – reparierte Version

## Durchgeführte Reparaturen

- fehlendes Timeline-Fortschrittselement ergänzt
- Fortschrittsbalken lässt sich antippen, ziehen und per Tastatur bedienen
- 5-Sekunden-Sprünge, Neustart und A/B-Loop synchronisiert
- Zeit, Canvas, Audio und Fortschrittsanzeige werden beim Spulen gemeinsam aktualisiert
- dynamische Songkarten funktionieren nun über Ereignisdelegation auch in Kinder- und Lernbereichen
- IndexedDB-Ausfall wird durch LocalStorage-Persistenz abgefangen
- Spieler pausiert beim Verlassen automatisch
- Audio-Objekt-URLs werden beim Songwechsel bereinigt
- Diagnosebereich prüft Parser, Bibliothek, Seek, Loop, Persistenz und Audio-Schnittstellen
- persönlicher Lieblingssong-Katalog aus den bereitgestellten Screenshots ergänzt

## Wichtiger Status der Lieblingssongs

Die kommerziellen Lieblingssongs sind als persönliche Bibliothekseinträge und neutrale Rhythmus-Templates vorhanden. Originalaudio, exakte Tabs und lizenzierte Arrangements sind **nicht kopiert**. Für eine exakte Spielspur importierst du legal nutzbare MIDI-, MusicXML-, ChordPro-, Text-Tab-, eigene Audio- oder später GuitarPro-Daten.

# Luca Guitar Quest Studio Pro

Eigenständige Gitarrenlern-App mit einer modernen, an Musiklern-Apps orientierten Struktur. Es wurden **keine geschützten Yousician-Codes, Datenbanken, Grafiken oder Originalassets kopiert**.

## Wesentliche Verbesserungen

- Fortschrittsbalken ist vollständig bedienbar:
  - antippen
  - ziehen
  - Tastatur-Pfeile
  - 5 Sekunden vor/zurück
  - Neustart
- A/B-Wiederholung mit Loop-Schalter
- echte Auswertung aus Trefferquote und Timing statt Zufallswerten
- lokale IndexedDB-Datenbank für:
  - eigene Songs
  - Quellen
  - Fortschritt
  - Einstellungen
  - eigene Audio-Dateien
- umfangreiche Bibliothek mit Filtern, Kategorien und Sortierung
- Modi:
  - Melodie
  - Akkorde
  - Rhythmus
- Kinderlied-Bereich
- Mikrofon-Erkennung für Einzeltöne
- einfache Akkorderkennung als Beta
- Stimmgerät
- Metronom
- Geschwindigkeit 50–150 %
- Imports:
  - MIDI
  - Text-Tab
  - ChordPro
  - MusicXML
  - Luca JSON
  - eigene Audio-Datei
  - GuitarPro als legale Quelle vorbereitet
- Spotify-/YouTube-Links als Referenz mit selbst erzeugter Akkord-/Rhythmusübung
- Diagnosebereich zur Funktionsprüfung
- Backup/Restore
- PWA und iPad-Layout

## Wichtige Grenzen

- Eine exakte Kopie von Yousician inklusive Code, Datenbank und lizenzierten Songs ist nicht zulässig und technisch ohne deren Rechte nicht möglich.
- Spotify- und YouTube-Audio wird nicht heruntergeladen oder extrahiert.
- Exakte kommerzielle Songdaten benötigen eine eigene Lizenz oder eine legal erworbene Datei.
- GuitarPro-Dateien werden als Quelle gespeichert. Ein vollständiger Parser für die proprietären Binärformate ist ein eigener größerer Modulbaustein.
- Mikrofonzugriff funktioniert im Browser nur über HTTPS oder localhost.

## iPad-Installation

1. Dateien auf einen HTTPS-Webspace laden.
2. `index.html` in Safari öffnen.
3. Teilen → **Zum Home-Bildschirm**.
4. Beim ersten Stimmgerät-/Spielstart Mikrofon erlauben.

## Luca-JSON-Beispiel

```json
{
  "title": "Meine Übung",
  "artist": "Luca",
  "category": "Import",
  "difficulty": 2,
  "bpm": 90,
  "key": "G",
  "timeSig": "4/4",
  "modes": {
    "chords": [
      {"id":"c1","timeMs":0,"durationMs":2000,"type":"chords","chord":"G","label":"G"},
      {"id":"c2","timeMs":2000,"durationMs":2000,"type":"chords","chord":"D","label":"D"}
    ]
  }
}
```
