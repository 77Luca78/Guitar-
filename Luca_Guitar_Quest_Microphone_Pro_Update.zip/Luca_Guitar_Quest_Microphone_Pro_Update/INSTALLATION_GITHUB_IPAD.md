# Luca Guitar Quest – Mikrofon Pro installieren

## Was dieses Update ergänzt

- deutlich höhere Mikrofonempfindlichkeit
- digitale Eingangsverstärkung von 1× bis 12×
- einstellbare Rauschschwelle von −80 bis −25 dB
- einstellbare Erkennungssicherheit
- Profile für leise Akustikgitarre, normale Akustikgitarre, unverstärkte E-Gitarre und laute Räume
- automatische Zweipunkt-Kalibrierung: Umgebungsgeräusch + normale Gitarrenlautstärke
- präziser, ausgewogener und schneller Analysemodus
- Hochpass-, Tiefpass- und Dynamikbearbeitung
- Live-Wellenform, Pegel, dB-Wert, Ton, Sicherheit und geschätzte Latenz
- Eingangsquellen-Auswahl, soweit Safari/iPadOS sie bereitstellt
- Aufnahme während des Übens und Spielens
- automatischer Aufnahmebeginn mit dem Player
- Pause/Fortsetzen der Aufnahme gemeinsam mit dem Player
- lokale Aufnahmeliste in IndexedDB
- Wiedergabe, Download, Teilen und Löschen von Aufnahmen
- Rhythmusanschläge über Pegelanstieg/Onset-Erkennung
- verbesserte Akkorderkennung
- offlinefähige Einbindung über den Service Worker

## Wichtige Grenze

Das Modul bildet vergleichbare Bedienfunktionen moderner Musiklern-Apps eigenständig nach. Es enthält keinen kopierten Yousician-Code, keine Yousician-Assets und keinen Zugriff auf deren interne Erkennungsalgorithmen.

## Upload auf GitHub

Repository:

`https://github.com/77Luca78/Guitar-`

### 1. `mic-pro.js` neu hochladen

1. Im Repository **Add file → Upload files** öffnen.
2. Die Datei `mic-pro.js` aus diesem Ordner auswählen.
3. Commit-Nachricht: `Mikrofon Pro und Aufnahmefunktion ergänzen`
4. **Commit directly to main** bestätigen.

### 2. `service-worker.js` ersetzen

1. Im Repository die vorhandene Datei `service-worker.js` öffnen.
2. Über das Stift-Symbol bearbeiten oder die Datei löschen und diese neue Datei hochladen.
3. Der Dateiname muss exakt `service-worker.js` bleiben.
4. Commit-Nachricht: `Offline-Cache für Mikrofon Pro aktualisieren`

Die neue Service-Worker-Datei fügt `mic-pro.js` automatisch in die App-Seite ein. `index.html` muss deshalb nicht von Hand verändert werden.

## Update auf dem iPad aktivieren

1. Öffne `https://77luca78.github.io/Guitar-/` in Safari.
2. Aktualisiere die Seite einmal.
3. Warte etwa 5 Sekunden.
4. Aktualisiere ein zweites Mal oder schließe die installierte Web-App vollständig und öffne sie erneut.
5. Im Player erscheint neben **Mikro** der neue Button **Mikro-Pro**.
6. Im Stimmgerät erscheint **Mikrofon einstellen**.

Falls die alte Version bleibt:

1. iPad **Einstellungen → Safari → Erweitert → Websitedaten** öffnen.
2. Nach `77luca78.github.io` suchen.
3. Nur diesen Website-Eintrag entfernen.
4. Die App-Seite erneut in Safari öffnen und anschließend wieder zum Home-Bildschirm hinzufügen.

## Empfohlener erster Test

1. **Stimmgerät → Mikrofon einstellen** öffnen.
2. Profil **Akustik · normal** wählen.
3. Mikrofon starten.
4. **Automatisch kalibrieren** drücken.
5. Zuerst 2 Sekunden ruhig sein.
6. Danach 4–6 Mal eine Saite in normaler Lautstärke anschlagen.
7. Anschließend eine offene E-, A-, D-, G-, B- oder e-Saite testen.

## Empfohlene Werte, falls die Gitarre weiterhin zu leise ist

- Profil: `Akustik · leise`
- Empfindlichkeit: `8× bis 10×`
- Rauschschwelle: `−70 dB`
- Erkennungssicherheit: `30–38 %`
- Analysemodus: `Ausgewogen`

Bei vielen Fehlreaktionen:

- Rauschschwelle schrittweise auf `−58 dB` oder `−50 dB` erhöhen
- Erkennungssicherheit auf `45–55 %` erhöhen
- iPad näher an das Schallloch stellen
- Hülle oder Tastatur so positionieren, dass das Mikrofon nicht verdeckt wird

## Aufnahme

1. Im Player **Mikro-Pro** öffnen.
2. **Aufnahme automatisch mit dem Player starten und stoppen** aktivieren.
3. Optional **Gefiltertes und verstärktes Gitarrensignal aufnehmen** aktivieren.
4. Player starten.
5. Beim Pausieren pausiert die Aufnahme; beim Fortsetzen läuft sie weiter.
6. Am Songende wird sie gespeichert.
7. Aufnahmen können angehört, geteilt, heruntergeladen und gelöscht werden.

Das Eingangsmithören ist standardmäßig ausgeschaltet. Es sollte nur mit Kopfhörern aktiviert werden, da es sonst zu Rückkopplungen kommen kann.
