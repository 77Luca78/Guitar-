# Testbericht – Mikrofon Pro

## Automatisch geprüft

- JavaScript-Syntax von `mic-pro.js`: bestanden
- JavaScript-Syntax von `service-worker.js`: bestanden
- Service-Worker-Cache enthält `mic-pro.js`: bestanden
- automatische HTML-Injektion von `mic-pro.js`: vorhanden
- sechs synthetische Gitarrensaiten bei sehr leisem Signal und leichtem Rauschen geprüft

## Synthetischer Pitch-Test

Testsignal: 48 kHz, 4096 Samples, leise Grundwelle mit Obertönen und Rauschen.

- E2 82,41 Hz → 82,38 Hz, Abweichung −0,56 Cent
- A2 110,00 Hz → 109,96 Hz, Abweichung −0,62 Cent
- D3 146,83 Hz → 146,83 Hz, Abweichung 0,00 Cent
- G3 196,00 Hz → 196,05 Hz, Abweichung +0,41 Cent
- B3 246,94 Hz → 246,78 Hz, Abweichung −1,11 Cent
- E4 329,63 Hz → 329,54 Hz, Abweichung −0,47 Cent

Alle synthetischen Tests lagen deutlich unter 8 Cent Abweichung.

## Noch auf dem echten iPad zu prüfen

- reale Empfindlichkeit des eingebauten iPad-Mikrofons
- Einfluss von Hülle, Tastatur, Raumhall und Abstand zur Gitarre
- verfügbare MediaRecorder-Formate der installierten iPadOS-Version
- Verhalten externer USB-/Bluetooth-Audioquellen
- reale Latenz bei gleichzeitigem Backingtrack und Mikrofonanalyse

Ein automatischer synthetischer Test ersetzt keinen physischen Gerätetest.
