# Mikrofon auf dem iPad aktivieren

1. Die App muss über eine Adresse beginnen, die mit `https://` startet.
2. Öffne diese Adresse in Safari.
3. Tippe in der App auf **Stimmgerät → Mikrofon starten**.
4. Erlaube den Mikrofonzugriff.
5. Falls zuvor abgelehnt: Safari → Seiteneinstellungen → Mikrofon → Erlauben.
6. Schlage nur eine Saite gleichzeitig an und halte das iPad etwa 30–80 cm von der Gitarre entfernt.

## Warum die entpackte ZIP nicht reicht
Wird `index.html` direkt aus der Dateien-App geöffnet, läuft sie meist als lokale Datei (`file://`). Browser geben der Seite dort aus Sicherheitsgründen keinen Live-Mikrofonzugriff. Das ist keine Tonerkennungsfrage, sondern eine Browser-Sperre.

## Prüfung in der App
- **Interne Tonanalyse testen** prüft den Algorithmus ohne echtes Mikrofon.
- Der Signalpegel zeigt, ob tatsächlich Ton im Browser ankommt.
- Die Erkennungssicherheit zeigt, ob der Ton stabil genug ist.
