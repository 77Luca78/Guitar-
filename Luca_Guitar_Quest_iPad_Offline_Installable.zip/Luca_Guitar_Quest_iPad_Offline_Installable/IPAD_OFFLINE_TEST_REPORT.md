# Prüfbericht · iPad Offline Edition

## Automatisch geprüft
- JavaScript-Syntax von `app.js`
- JavaScript-Syntax des Service Workers
- gültiges Web-App-Manifest
- Vorhandensein aller gecachten Kerndateien
- App-Symbole in 180, 192, 512 und 1024 Pixel
- Startbilder für iPad Pro 13 Zoll im Hoch- und Querformat
- Netzwerk-Schalter standardmäßig aus
- externe Links über zentrale Freigabefunktion abgesichert
- Offline-Cache-Prüfung in den Einstellungen
- Manifest im Standalone-Modus und flexible Ausrichtung

## Nicht physisch prüfbar
- reales Mikrofon des konkreten iPad
- Verhalten der aktuell installierten iPadOS-Version bei jeder Berechtigungskombination
- Installation über eine noch nicht bereitgestellte öffentliche HTTPS-Adresse

Diese Punkte müssen nach Veröffentlichung einmal auf dem tatsächlichen iPad geprüft werden.
