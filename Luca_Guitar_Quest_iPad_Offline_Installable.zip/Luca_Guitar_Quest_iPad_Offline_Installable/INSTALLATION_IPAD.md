# Installation auf dem iPad Pro 13 Zoll (M4)

## 1. Einmalig veröffentlichen
Der entpackte Ordner muss auf einer HTTPS-Adresse liegen. Nutze dafür zum Beispiel GitHub Pages, Netlify oder Cloudflare Pages.

## 2. Als App installieren
1. Öffne die HTTPS-Adresse in Safari.
2. Tippe auf **Teilen**.
3. Wähle **Zum Home-Bildschirm**.
4. Aktiviere **Als Web-App öffnen**.
5. Tippe auf **Hinzufügen**.
6. Starte Luca Guitar Quest über das neue Symbol.
7. Lass die App beim ersten Start vollständig laden.
8. Öffne **Einstellungen → Offline & Netzwerk → Offline-Speicher prüfen**.

## 3. Offline verwenden
- **Internet-Funktionen erlauben** ausgeschaltet lassen.
- Lernpfad, lokale Songs, Kinderlieder, Fortschritt, Stimmgerät, Mikrofonfeedback und Dateiimporte bleiben verfügbar.
- Externe Spotify-/YouTube-/Quellenlinks bleiben gesperrt, bis du sie bewusst erlaubst.

## Mikrofon
Der erste Mikrofonzugriff muss aus einer HTTPS-Web-App erfolgen. Tippe im Stimmgerät auf **Mikrofon starten** und erlaube den Zugriff. Die anschließende Tonanalyse läuft lokal auf dem iPad und benötigt keine Internetverbindung.

## Empfehlung
Für Player, Timeline und Live-Feedback ist das Querformat am übersichtlichsten. Die übrigen Bereiche funktionieren auch hochkant.
