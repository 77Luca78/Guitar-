# Bekannte Grenzen

- Live-Mikrofon benötigt einen sicheren HTTPS-Kontext und eine erteilte Browserberechtigung.
- Kommerzielle Songs sind Referenz- und Rhythmus-Templates, keine kopierten Arrangements.
- Akkorderkennung bleibt eine Beta-Funktion; Einzeltöne werden deutlich zuverlässiger erkannt.
- Sehr laute Nebengeräusche, gleichzeitig abgespielte Musik oder mehrere klingende Saiten erschweren die Erkennung.
- GuitarPro-Binärformate sind als Quellen vorbereitet, aber nicht vollständig geparst.
