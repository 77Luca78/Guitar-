# Architektur-Leitfaden – Luca Guitar Quest Studio Pro

## 1. Zielbild

Die App ist eine eigenständige Gitarrenlern-PWA. Sie übernimmt keine geschützten Codes, Datenbanken oder Arrangements anderer Anbieter. Die Oberfläche orientiert sich an etablierten Lernmustern: Lernpfad, Songbibliothek, Detailseite, Spielmodus, Fortschritt, Sterne und Wiederholungsbereiche.

## 2. Schichten

### Oberfläche
- `index.html`: Navigation, Lernpfad, Bibliothek, Import, Stimmgerät und Player
- `styles.css`: responsive iPad-/Smartphone-Oberfläche
- `app.js`: Daten, Player, Parser, Mikrofon, Datenbank und Diagnose

### Datenhaltung
IndexedDB speichert:
- `songs`: importierte und eigene Übungen
- `progress`: XP, Sterne, Bestwerte, letzte Songs
- `sources`: Rechtsstatus und Herkunft
- `audio`: eigene Audiodateien
- `settings`: Barrierefreiheit und Spieleroptionen

Falls IndexedDB nicht verfügbar ist, werden Songs, Fortschritt, Quellen und Einstellungen über LocalStorage gesichert. Eigene Audiodateien benötigen IndexedDB.

### Songmodell
Ein Song besitzt Metadaten und einen oder mehrere Modi:

```json
{
  "id": "song-id",
  "title": "Titel",
  "artist": "Künstler",
  "category": "Songkurs",
  "difficulty": 2,
  "bpm": 90,
  "source": "import",
  "rights": "Eigene Datei",
  "modes": {
    "melody": [],
    "chords": [],
    "rhythm": []
  }
}
```

### Ereignismodell
- Melodie: `timeMs`, `durationMs`, `string`, `fret`, `midi`
- Akkord: `timeMs`, `durationMs`, `chord`
- Rhythmus: `timeMs`, `durationMs`, `direction`

## 3. Player

Der Player verwendet eine gemeinsame Zeitachse in Millisekunden. Folgende Teile werden synchronisiert:
- Canvas-Spielbrett
- Timeline
- Audio-Datei
- Metronom
- Trefferwertung
- A/B-Loop

Beim Spulen werden Canvas, Zeitanzeige und Audio sofort aktualisiert. Während des Ziehens pausiert die interne Zeitfortschreibung, damit der Regler nicht gegen den Player „kämpft“.

## 4. Bewertung

- Trefferquote: richtige Ereignisse / Gesamtzahl
- Timingwertung: Abstand zum Zielzeitpunkt innerhalb des Trefferfensters
- Gesamtwertung: 70 % Trefferquote, 30 % Timing
- Sterne: 1 ab 50 %, 2 ab 75 %, 3 ab 90 %
- XP: Grundwert + Sterne + Gesamtwertung

## 5. Importmodule

Direkt spielbar:
- MIDI
- Text-Tab
- ChordPro
- MusicXML
- Luca JSON
- eigene Audio-Datei mit Rhythmusübung

Vorbereitet:
- GuitarPro/GPX als legale Quelle; vollständige proprietäre Binärparser sind ein getrenntes Modul

## 6. Lieblingssong-Katalog

Die aus den Screenshots übernommene persönliche Liste enthält 151 Referenzeinträge. Diese enthalten neutrale Rhythmus-Templates, aber keine kopierten Original-Tabs oder Audiodaten. Exakte Spielspuren entstehen erst durch legal importierte Songdaten.

## 7. Erweiterungspunkte

- genauer GuitarPro-Parser über legal verfügbare Bibliothek
- Mehrspur-MIDI-Auswahl
- Audio-Wellenform und Takterkennung
- bessere polyphone Akkorderkennung
- Cloud-Synchronisation mit Benutzerkonto
- Lehrer-/Kita-Modus mit eigenen Kurslisten
- Songabschnitte: Intro, Strophe, Refrain, Solo
