# Mikrofon- und Tonerkennungs-Testbericht

## Behoben

- AudioContext wird nach einer direkten Benutzeraktion fortgesetzt (`resume()`).
- Mikrofonstart prüft sicheren Kontext, Browser-API, Berechtigung und aktiven Audiokanal.
- Die frühere einfache Autokorrelation wurde durch eine YIN-basierte Tonhöhenerkennung ersetzt.
- Analyse wird gedrosselt, damit sie auf Tablets weniger Prozessorlast erzeugt.
- Signalpegel, Erkennungssicherheit, Frequenz, Cent-Abweichung und Zielsaite werden sichtbar angezeigt.
- Der Spielmodus zeigt den live erkannten Ton und den aktuellen Zielton.
- Gegriffene Noten werden nach MIDI-Tonhöhe geprüft, nicht nur nach der Saite.
- Gehaltene Töne erzeugen nicht mehr laufend falsche Fehlversuche.
- Verständliche Meldungen für `file://`, verweigerte Berechtigung, fehlendes Mikrofon und belegtes Mikrofon.

## Automatische Prüfungen

- JavaScript-Syntaxprüfung mit Node.js: bestanden.
- Synthetische Tonanalyse bei 48.000 Hz für E2, A2, D3, G3, B3 und E4: bestanden.
- Maximale Abweichung im synthetischen Test: unter 0,04 Cent.
- Alle neuen HTML-Elemente und JavaScript-Funktionen sind vorhanden.

## Nicht in dieser Umgebung prüfbar

Ein echtes iPad-Mikrofon kann hier nicht physisch angesprochen werden. Der reale Gerätetest muss deshalb auf deinem iPad über eine HTTPS-Adresse erfolgen. Die App zeigt jetzt direkt an, ob die Ursache fehlendes HTTPS, eine verweigerte Berechtigung, ein zu leises Signal oder eine instabile Tonerkennung ist.
