# Luca Guitar Quest Studio Pro · Offline iPad Edition

Installierbare Progressive Web App für das iPad Pro 13 Zoll (M4).

## Offline-first
- Lernpfad, Bibliothek, Kinderlieder, Imports, Fortschritt, Stimmgerät und Mikrofonanalyse benötigen nach der Installation keine Internetverbindung.
- Internet-Funktionen sind standardmäßig ausgeschaltet.
- Spotify-, YouTube- und externe Quellenlinks lassen sich in den Einstellungen bewusst freigeben.
- Der Service Worker speichert HTML, CSS, JavaScript, Symbole, Startbilder und den lokalen Songkatalog.

## Installation
Die PWA muss einmal über HTTPS in Safari geöffnet und zum Home-Bildschirm hinzugefügt werden. Danach die App einmal vollständig online starten, damit der Offline-Cache aufgebaut wird.

Siehe `INSTALLATION_IPAD.md` und `DEPLOYMENT_GUIDE.md`.

## Wichtige Grenze
Eine PWA ist keine signierte IPA-Datei. Eine echte App-Store-/TestFlight-App benötigt Apple-Signierung und einen iOS-Build. Für deine aktuelle Ausstattung ist die installierbare PWA die praktischste Lösung.
