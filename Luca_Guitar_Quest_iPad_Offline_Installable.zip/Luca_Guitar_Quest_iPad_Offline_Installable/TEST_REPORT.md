# Testbericht – reparierte Version

## Statische Prüfungen

- JavaScript-Syntax mit Node.js geprüft: bestanden
- alle statisch referenzierten HTML-IDs vorhanden
- Manifest, Service Worker, CSS und App-Skript im Paket vorhanden
- Service-Worker-Cacheversion erhöht, damit ältere fehlerhafte Dateien ersetzt werden

## Automatisierte Browserprüfung

Getestet in Headless Chromium mit Desktop- und iPad-ähnlicher Bildschirmgröße:

- App startet ohne JavaScript-Laufzeitfehler
- 173 Bibliothekseinträge werden geladen
- 151 persönliche Lieblingssong-Referenzen sind vorhanden
- Startkarten öffnen Songdetails
- Kinderlied-Karten öffnen Songdetails
- Referenzsongs zeigen den rechtlichen/technischen Status korrekt
- Player startet
- Timeline kann auf einen beliebigen Wert gesetzt werden
- Timeline kann direkt angeklickt werden
- Fortschrittsfüllung und Zeitanzeige aktualisieren sich
- 5 Sekunden vor/zurück funktioniert
- A/B-Punkte und Loop-Schalter funktionieren
- Player pausiert beim Verlassen der Playeransicht
- Song-Suche findet Referenztitel wie „Snuff“
- Lieblingssong kann als eigene Akkordübung gespeichert werden
- Luca-JSON-Import funktioniert
- MIDI-Schnellimport funktioniert mit einer Testdatei
- Text-Tab mit zweistelligem Bund wird nicht doppelt gelesen
- ChordPro akzeptiert Klammerformat und reine Akkordfolgen
- MusicXML-Testdatei wird gelesen
- hoher Kontrast und mobile Navigation funktionieren
- interne Diagnose meldet keine internen Funktionsfehler

## Umgebungsabhängige Funktionen

Diese Punkte können nicht ohne reale Gerätefreigabe vollständig automatisiert werden:

- Mikrofonzugriff benötigt HTTPS und Zustimmung auf dem iPad
- PWA-/Service-Worker-Installation benötigt HTTPS oder localhost
- Audioeingangsqualität hängt von Raum, Mikrofon und Gitarrenlautstärke ab

Die App behandelt diese Punkte als Hinweise und nicht als internen Programmfehler.
