# HTTPS-Veröffentlichung ohne eigenen Computer

## GitHub Pages
1. Öffne GitHub in Safari und erstelle ein neues öffentliches Repository.
2. Lade alle Dateien aus diesem Ordner in das Repository hoch.
3. Öffne Settings → Pages.
4. Wähle Deploy from a branch, Branch main und Ordner /(root).
5. Öffne nach der Veröffentlichung die angezeigte HTTPS-Adresse.

## Netlify
Der Ordner enthält bereits netlify.toml und _headers. Lade den entpackten Ordner in eine neue statische Netlify-Site hoch.

## Danach
Öffne die HTTPS-Adresse in Safari und füge sie zum Home-Bildschirm hinzu.
