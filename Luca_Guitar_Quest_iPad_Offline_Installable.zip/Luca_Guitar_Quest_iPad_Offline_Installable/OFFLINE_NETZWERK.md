# Offline- und Netzwerkmodus

## Standard
Die App startet mit ausgeschalteten Internet-Funktionen. Externe Links werden nicht ohne Nachfrage geöffnet.

## Lokal verfügbar
- komplette Benutzeroberfläche
- Lernpfad und lokale Bibliothek
- Song- und Kinderliedübungen
- Sterne, XP und Fortschritt
- Mikrofonanalyse und Stimmgerät
- MIDI-, ChordPro-, Text-Tab-, MusicXML-, Luca-JSON- und eigene Audioimporte, soweit vom Browser unterstützt
- Backups

## Internet nur optional
Internet wird nur für externe Spotify-, YouTube- und Quellenlinks benötigt. Die App fragt vor dem ersten Öffnen nach Freigabe. Die Einstellung lässt sich jederzeit wieder deaktivieren.

## Erster Start
Die Dateien müssen einmal über HTTPS geladen werden, damit Safari den Service Worker und Offline-Cache einrichten kann.
